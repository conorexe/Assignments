// myshell.c
#include "myshell.h"

int main(int argc, char **argv) {
    return main_(argc, argv);
}
